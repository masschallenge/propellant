MassChallenge brand kit

Everything you need to make something on brand. The full guide, with the rules for each
file, is at https://propellant.masschallenge.org/brand/

logos/
  The MassChallenge horizontal logo and MC mark as PNG files, in three treatments.
  The vertical logo is the default for most layouts, and the horizontal logo is for
  headers, footers, sponsor slides and banners. Vertical and local logo files come from
  MassChallenge Marketing. Use the MC mark where the audience already knows us, such as
  a favicon, an avatar or compact navigation.
  color: on White or Warm White only.
  white: on Navy, Black, Deep Teal, Teal, MC Blue and photos with enough contrast.
  black: for one color printing, and light backgrounds the color logo does not suit.
  Give the logo clear space equal to the height of the M in MASSCHALLENGE on every side.
  Keep the horizontal logo at least 160px wide on screen (30mm in print), and the MC mark
  at least 16px tall on screen (8mm in print).
  Never recolor, stretch, rotate, outline, flip, crop, rebuild or retype it. Always use
  these files.

design-system-only/
  The Propellant mark, as SVG. It stands for the Propellant design system and nothing
  else. Never use it in place of the MassChallenge logo.

fonts/
  Propellant Sans (Lato 2.0) and Oswald, as web fonts (.woff2), with their SIL Open Font
  License files. Oswald is for headlines, always in capitals. Lato is for reading text.
  For Word, PowerPoint and Excel, install Lato and Oswald from Google Fonts:
  https://fonts.google.com/specimen/Lato and https://fonts.google.com/specimen/Oswald
  Where they will not load, use Aptos Narrow Bold in capitals for headers and Aptos for
  text. Never Arial.

colors.txt and colors.json
  The brand palette, the supporting neutrals and the logo colors with HEX, RGB,
  approximate CMYK, print substitutes and Propellant tokens where they exist.
