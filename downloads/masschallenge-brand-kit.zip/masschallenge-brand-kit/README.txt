MassChallenge brand kit

Everything you need to make something on brand. The full guide, with the rules for each
file, is at https://propellant.masschallenge.org/brand/

logos/
  The MassChallenge logo as PNG files, in two lockups and three treatments.
  Horizontal is the default. Use the monogram only in small spaces, such as a favicon or
  an avatar, where the MassChallenge name is already clear.
  color: on white and light backgrounds.
  white: on Deep teal, dark backgrounds and dark, calm parts of photos.
  black: for one color printing.
  Give the logo clear space of half its height on every side. Keep the horizontal logo at
  least 24px tall on screen, and the monogram at least 16px.
  Never stretch, recolor, redraw, outline or crop it. There is no vector original of the
  MassChallenge logo, so always use these files.

design-system-only/
  The Propellant mark, as SVG. It stands for the Propellant design system and nothing
  else. Never use it in place of the MassChallenge logo.

fonts/
  Propellant Sans (Lato 2.0) and Oswald, as web fonts (.woff2), with their SIL Open Font
  License files. Lato is for everything. Oswald is only for big display headlines, set in
  capitals. For Word, PowerPoint and Excel, install Lato and Oswald from Google Fonts:
  https://fonts.google.com/specimen/Lato and https://fonts.google.com/specimen/Oswald

colors.txt and colors.json
  The brand palette, the supporting neutrals and the logo colors with HEX, RGB, print CMYK
  and the Propellant token for each, and how the CMYK values were calculated.
